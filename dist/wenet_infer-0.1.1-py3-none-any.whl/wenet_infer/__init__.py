from .wenet_model import load_model
