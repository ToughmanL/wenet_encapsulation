from wenet.cli.model import load_model  # noqa
