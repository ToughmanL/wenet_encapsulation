from wenet.cli.model import loadmodel  # noqa
